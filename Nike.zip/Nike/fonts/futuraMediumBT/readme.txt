﻿ Copyright (C) 2008-2011 Free Time

This software is provided 'as-is', without any express or implied warranty. In
no event will the authors be held liable for any damages arising from the use of
this software.

Your privacy is important to us. Our software and website will not collect any
information in your PC.

Welcome to spread FormatFactory without any modification

You can use this software for any purpose, including commercial applications,
and to alter it and redistribute it freely.
    